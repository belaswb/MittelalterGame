﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Generic;
using System.IO;


public partial class ChatServer
{
    static ManualResetEvent waitForConnectionEvent = new ManualResetEvent(false);

    const int maxGroupSize = 5;
    static List<Player> players = new List<Player>();
    static List<Socket> gameServers = new List<Socket>();
    static List<Group> groups = new List<Group>();

    static Dictionary<string, System.Timers.Timer> pendingKicks = new Dictionary<string, System.Timers.Timer>();
    static Dictionary<Player, System.Timers.Timer> pendingInvites = new Dictionary<Player, System.Timers.Timer>();

    static Dictionary<string, int> characterIds = new Dictionary<string, int>(); // [character name : character id] - Only characters that are in guilds are in this dictionary!
    static Dictionary<int, int> characterGuilds = new Dictionary<int,int>(); // [character id - guild id]
    static HashSet<int> guildLeaders = new HashSet<int>(); //ids of the characters which are guild leaders
    static Dictionary<int, string> guildNames = new Dictionary<int,string>(); //[guild id - guild name]

    static string Hostname; //for php scripts, is loaded from hostname.ini

    public static void Main(string[] args)
    {
        using (var myFile = new StreamReader("hostname.ini"))
        {
            Hostname = myFile.ReadToEnd(); // Read the file as one string            
        }
        Console.WriteLine("url: " + Hostname);
        ConQue.Enqueue(() => StartGuildsUpdate()); // download guilds from DB on first launch

        _ = ProcessorLoop(); // launch the loop that will 'tick' once every 8ms. It will process Actions on the concurrent queue.

        StartListening(); // Each connection will run asynchronously.
    }

    public static void StartListening()
    {
        // People can connect from any IP, to the 3457 port.
        IPEndPoint localEndPoint = new IPEndPoint(IPAddress.Any, 3457);

        // Create an ipv4 TCP/IP socket
        Socket listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        // Bind the socket to the local endpoint and listen for incoming connections.
        try
        {
            listener.Bind(localEndPoint);
            listener.Listen(100);

            while (true)
            {
                // Set the event to nonsignaled state.
                waitForConnectionEvent.Reset();

                // Start an asynchronous socket to listen for connections.
                //Console.WriteLine("Waiting for a new connection...");
                listener.BeginAccept(
                    new AsyncCallback(AcceptCallback),
                    listener);

                // Wait until a connection is made before continuing.
                waitForConnectionEvent.WaitOne();
            }

        }
        catch (Exception e)
        {
            Console.WriteLine(e.ToString());
        }
    }

    public static void AcceptCallback(IAsyncResult ar)
    {
        // Signal the main thread to continue.
        waitForConnectionEvent.Set();

        // Get the socket that handles the client request.
        Socket listener = (Socket)ar.AsyncState;
        Socket handler = listener.EndAccept(ar);

        // Create the state object.
        StateObject state = new StateObject();
        state.workSocket = handler;
        try
        {
            handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReadMessage), state);
        }
        catch (Exception)
        {
            ConQue.Enqueue(() => KickConnection(handler));
            handler.Close();
        }
    }

    public static void ReadMessage(IAsyncResult ar)
    {
        // Retrieve the state object and the handler socket from the asynchronous state object.
        StateObject state = (StateObject)ar.AsyncState;
        Socket connection = state.workSocket;
        if (!connection.Connected)
            return;
        try
        {
            int bytesRead = connection.EndReceive(ar);

            // disconnect happened
            if (bytesRead == 0)
            {
                ConQue.Enqueue(() => KickConnection(connection));
                connection.Close();
                return;
            }

            //Read the first byte to determine the type of "command" we received and switch on it
            Stream stream = new MemoryStream(state.buffer);
            BinaryReader reader = new BinaryReader(stream);
            while (reader.PeekChar() > 0) // -1 is "end of stream", "0" is "undefined"
            {
                Command cmd = (Command)reader.ReadByte();
                switch (cmd)
                {                
                case Command.Login: ReadLogin(reader, connection); break;
                //case Command.Logout: break; // no need, a dropped connection is caught elsewhere
                case Command.GeneralMessage: ReadGeneralMessage(reader, connection); break;
                case Command.PrivateMessage: ReadPrivateMessage(reader, connection); break;
                case Command.GroupMessage: ReadGroupMessage(reader, connection); break;
                case Command.GuildMessage: ReadGuildMessage(reader, connection); break;
                case Command.GroupInvite: ReadGroupInvite(reader, connection); break;
                case Command.AcceptInvite: ReadAcceptInvite(connection); break; // accept group invite or guild invite
                case Command.DeclineInvite: ReadDeclineInvite(connection); break;
                case Command.GuildCreate: ReadGuildCreate(reader, connection); break;
                case Command.GuildInvite: ReadGuildInvite(reader, connection); break;
                case Command.GuildDisband: ReadGuildDisband(connection); break;
                case Command.GuildLeave: ReadGuildLeave(connection); break;
                case Command.GroupLeave: ReadGroupLeave(connection); break;
                case Command.GuildKick: ReadGuildKick(reader, connection); break;
                case Command.GroupKick: ReadGroupKick(reader, connection); break;
                }
            }

            // listen again:          
            state.ResetBuffer();
            connection.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReadMessage), state);
        }
        catch (SocketException socketException)
        {
            //WSAECONNRESET, the other side closed impolitely 
            if (socketException.ErrorCode == 10054 ||
                ((socketException.ErrorCode != 10004) &&
                (socketException.ErrorCode != 10053)) )
            {
                Console.WriteLine("remote client disconnected");
            }
            else Console.WriteLine(socketException.Message);
            ConQue.Enqueue(() => KickPlayer(connection));
            connection.Close(); //@TODO: is this necessary?
        }
        catch (EndOfStreamException)
        {
            Console.WriteLine("EndOfStreamException exception");
            // listen again:   
            state.ResetBuffer();
            connection.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReadMessage), state);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message + "\n" + e.StackTrace);
            ConQue.Enqueue(() => KickPlayer(connection));
            connection.Close();//@TODO: check if this is necessary
        }        
    }
}