﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

public enum Command
{
    Undefined,          //0 - Undefined
    Login,              //1 - Log into the server
    Logout,             //2 - Logout of the server
    GeneralMessage,     //3 - Send a text message to all the chat clients
    PrivateMessage,     //4
    GroupInvite,        //5
    GroupLeave,         //6
    GroupUpdate,        //7 - is sent to the game servers
    AcceptInvite,       //8 - used both for groups and guilds
    DeclineInvite,      //9 - used both for groups and guilds
    GroupMessage,       //10
    GroupKick,          //11       
    GuildLeave,         //12
    GuildInvite,        //13    
    NotUsed,            //14   -- not used
    NotUsed2,           //15   -- not used
    GuildMessage,       //16
    GuildKick,          //17
    GuildUpdate,        //18 - is sent to the game servers
    GuildCreate,        //19
    GuildDisband,       //20
}

public static class ExtensionMethods
{
    // Used on servers. Send or fail silently. We don't kick servers even if a Send() fails for some reason.
    public static bool SendOrFail(this Socket socket, byte[] buffer)
    {
        try
        {
            socket.Send(buffer);
            return true;
        }
        catch
        {
            return false;
        }

    }

    public static string ReadMmoString(this BinaryReader reader)
    {
        int strLen = reader.ReadInt32();
        var stringbytes = reader.ReadBytes(strLen);
        string result = Encoding.UTF8.GetString(stringbytes);
        return result;
    }
}

// State object for reading client data asynchronously
public class StateObject
{
    // Client  socket.
    public Socket workSocket = null;
    // Size of receive buffer.
    public const int BufferSize = 1024;
    // Receive buffer.
    public byte[] buffer = new byte[BufferSize];
    // Received data string.
    public StringBuilder sb = new StringBuilder();

    public void ResetBuffer()
    {
        sb.Clear();
        buffer = new byte[BufferSize];
    }
}

public class Player
{
    public Socket socket;

    public string name;
    public int id = -1;

    public Group group;
    public int guildid;
    public bool isGuildLeader;
    public Player(Socket inSocket, string inName)
    {
        socket = inSocket;
        name = inName;
    }

    public Player pendingInvite; //the player who invited this player and is waiting for a reply
    public bool hasPendingGuildInvite;

    // If Send fails, we kick the player, because he left.
    public bool SendOrKick(byte[] buffer)
    {        
        if (socket == null || !socket.SendOrFail(buffer))
        {
            ChatServer.KickPlayer(this);
            return false;
        }
        return true;
    }
}

public class Group
{
    public Group(Player player1, Player player2)
    {
        groupMembers = new List<Player>() { player1, player2 };
        player1.group = player2.group = this;
        leader = player1;
    }

    public List<Player> groupMembers;

    public Player leader;
    public string GetPlayerNames()
    {
        string result = string.Join(",", groupMembers.Select(x => x.name));
        return result;
    }

    public void UpdateReconnectedPlayer(Player reconnectedPlayer)
    {
        var foundPlayer = groupMembers.Where(player => player.name == reconnectedPlayer.name).SingleOrDefault();
        if (foundPlayer != null)
        {
            foundPlayer = reconnectedPlayer;
        }
    }
}

public class Data
{
    //Default constructor
    public Data()
    {
        this.cmdCommand = Command.Undefined;
        this.strMessage = null;
        this.strName = null;
    }

    //Converts the bytes into an object of type Data
    public Data(byte[] data)
    {
        //The first four bytes are for the Command
        this.cmdCommand = (Command)BitConverter.ToInt32(data, 0);

        //The next four store the length of the name
        int nameLen = BitConverter.ToInt32(data, 4);

        //The next four store the length of the message
        int msgLen = BitConverter.ToInt32(data, 8);

        //This check makes sure that strName has been passed in the array of bytes
        if (nameLen > 0)
            this.strName = Encoding.UTF8.GetString(data, 12, nameLen);
        else
            this.strName = null;

        //This checks for a null message field
        if (msgLen > 0)
            this.strMessage = Encoding.UTF8.GetString(data, 12 + nameLen, msgLen);
        else
            this.strMessage = null;
    }

    //Converts the Data structure into an array of bytes
    public byte[] ToBytes()
    {
        List<byte> result = new List<byte>();

        //First four are for the Command
        result.AddRange(BitConverter.GetBytes((int)cmdCommand));

        //Add the length of the name
        if (strName != null)
            result.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetByteCount(strName)));
        //result.AddRange(BitConverter.GetBytes(strName.Length));
        else
            result.AddRange(BitConverter.GetBytes(0));

        //Length of the message
        if (strMessage != null)
            //result.AddRange(BitConverter.GetBytes(strMessage.Length));
            result.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetByteCount(strMessage)));
        else
            result.AddRange(BitConverter.GetBytes(0));

        //Add the name
        if (strName != null)
            result.AddRange(Encoding.UTF8.GetBytes(strName));

        //And, lastly we add the message text to our array of bytes
        if (strMessage != null)
            result.AddRange(Encoding.UTF8.GetBytes(strMessage));

        return result.ToArray();
    }

    public string strName;      //Name by which the client logs into the room
    public string strMessage;   //Message text
    public Command cmdCommand;  //Command type (login, logout, send message, etcetera)
}

public class GuildsOutput
{
    public string status { get; set; }
    public List<CharacterRow> clans { get; set; }
}

public class CharacterRow
{
    public int character_id { get; set; }
    public string character_name { get; set; }
    public int clan_id { get; set; }
    public string clan_name { get; set; }
    public bool is_leader { get; set; }
}

public partial class ChatServer
{
    private static async Task<string> SendPhpRequestAsync(string script, string json)
    {
        var httpWebRequest = (HttpWebRequest)WebRequest.Create(Hostname + script + ".php");
        httpWebRequest.ContentType = "application/json";
        httpWebRequest.Method = "POST";

        using (var streamWriter = new StreamWriter(await httpWebRequest.GetRequestStreamAsync()))
        {
            streamWriter.Write(json);
        }

        HttpWebResponse httpResponse = (HttpWebResponse)await httpWebRequest.GetResponseAsync();
        using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
        {
            return await streamReader.ReadToEndAsync();
        }
    }

    public static byte[] MergeByteArrays(params object[] list)
    {
        int totalBytesLength = 0;
        for (int i = 0; i < list.Length; i++)
            totalBytesLength += ((byte[])list[i]).Length;

        byte[] result = new byte[totalBytesLength];
        int pos = 0;
        for (int i = 0; i < list.Length; i++)
        {
            byte[] thisArray = (byte[])list[i];
            thisArray.CopyTo(result, pos);
            pos += thisArray.Length;
        }
        return result;
    }

    public static byte[] ToBytes(Command rpc)
    {
        return new byte[1] { (byte)rpc };
    }

    public static byte[] WriteMmoString(string str)
    {
        return MergeByteArrays(ToBytes(Encoding.UTF8.GetBytes(str).Length), Encoding.UTF8.GetBytes(str));
    }

    public static byte[] ToBytes(int num)
    {
        byte[] bytes = BitConverter.GetBytes(num);
        return bytes;
    }

    public static byte[] ToBytes(float num)
    {
        byte[] bytes = BitConverter.GetBytes(num);
        if (!BitConverter.IsLittleEndian)
        {
            bytes = bytes.Reverse().ToArray();
        }
        return bytes;
    }
}