﻿using System;
using System.Net.Sockets;
using System.Linq;
using System.Collections.Concurrent;
using System.Threading.Tasks;

/* 
 * This file only contains Process methods.
 */

public partial class ChatServer
{ 
    static ConcurrentQueue<Action> ConQue = new ConcurrentQueue<Action>();

    /* 
     * The method gets called once every 8ms (120 times per second) from void Main.
     * It tries to read an Action from the queue and Invoke it on the main thread. It avoids concurrency issues.
     */
    public static async Task ProcessorLoop()
    {        
        while (true)
        {
            process_queue:
            if (ConQue.TryDequeue(out Action result))
            {
                await Task.Run(result);
                goto process_queue;
            }
            await Task.Delay(8);
        }
    }

    public static void ProcessLogin(string charName, Socket connection)
    {
        if (charName == "i am a game server") // Dear Gamedev! Change it to something else, it acts as a passphrase for the server to connect as one.
        {
            gameServers.Add(connection);
            InitializeGroupsOnServer();
            Console.WriteLine("A server logged in.");
        }
        else
        {
            PlayerLogin(connection, charName);
            Console.WriteLine("Player logged in: " + charName);
        }
    }

    public static void ProcessGeneralMessage(string message, Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null) return;
        Console.WriteLine(thisPlayer.name + ": " + message);

        // crop it if you don't want it too long, or log it to a file, or apply censorship filter on it, etc...
        byte[] distributeMessage = MergeByteArrays(ToBytes(Command.GeneralMessage),
            WriteMmoString(thisPlayer.name), // who messages
            WriteMmoString(message)); // the message itself

        foreach (Player player in players)
        {
            player.SendOrKick(distributeMessage);
        }
    }

    public static void ProcessPrivateMessage(string playerMessage, string targetPlayerName, Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null) return;
        Console.WriteLine($"{thisPlayer.name} to {targetPlayerName}: {playerMessage}");

        Player targetPlayer = players.Where(x => string.Compare(x.name, targetPlayerName, true) == 0).SingleOrDefault(); //case insensitive
        if (targetPlayer != null)
        {
            byte[] message = MergeByteArrays(ToBytes(Command.PrivateMessage),
            WriteMmoString(thisPlayer.name), // who messages
            WriteMmoString(playerMessage)); // the message itself

            // Altering message so that it appears as "To TargetPlayer: Message" to the player who sent it
            byte[] alteredMessage = MergeByteArrays(ToBytes(Command.PrivateMessage),
            WriteMmoString("To " + targetPlayerName), // to whom
            WriteMmoString(playerMessage)); // the message itself

            targetPlayer.SendOrKick(message);
            thisPlayer.SendOrKick(alteredMessage);
        }
    }

    public static void ProcessGroupMessage(string playerMessage, Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null || thisPlayer.group == null) return;
        Console.WriteLine($"[Group] {thisPlayer.name}: {playerMessage}");

        byte[] message = MergeByteArrays(ToBytes(Command.GroupMessage),
        WriteMmoString(thisPlayer.name), // who messages
        WriteMmoString(playerMessage)); // the message itself

        foreach (Player groupMember in thisPlayer.group.groupMembers)
            groupMember.SendOrKick(message);
    }

    public static void ProcessGuildMessage(string playerMessage, Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null || thisPlayer.guildid == 0) return;
        Console.WriteLine($"[Guild] {thisPlayer.name}: {playerMessage}");

        byte[] message = MergeByteArrays(ToBytes(Command.GuildMessage),
        WriteMmoString(thisPlayer.name), // who messages
        WriteMmoString(playerMessage)); // the message itself

        foreach (Player guildMember in players.Where(x => x.guildid == thisPlayer.guildid))
            guildMember.SendOrKick(message);
    }

    public static void ProcessGroupInvite(string targetPlayerName, Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null) return;
        Player targetPlayer = GetPlayerByName(targetPlayerName);
        if (targetPlayer == null || targetPlayer == thisPlayer) return;

        //@TODO: return reason for invitation failure to the inviting player
        if (thisPlayer.group != null && thisPlayer.group.leader != thisPlayer) return; //if the inviting player is not the group's leader
        if (thisPlayer.group != null && thisPlayer.group.groupMembers.Count >= maxGroupSize) return; //check max group size
        if (targetPlayer.group != null || targetPlayer.pendingInvite != null) return; //if the player is already in a group or being invited

        CreatePendingInvite(targetPlayer, thisPlayer, false);

        byte[] message = MergeByteArrays(ToBytes(Command.GroupInvite),
        WriteMmoString(thisPlayer.name)); // who invites
        targetPlayer.SendOrKick(message);
    }

    public static void ProcessAcceptInvite(Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null) return;
        Player invitingPlayer = thisPlayer.pendingInvite;
        if (invitingPlayer == null) return;        

        if (thisPlayer.hasPendingGuildInvite) //for guild invite
        {
            if (thisPlayer.guildid != 0 || invitingPlayer.guildid == 0)
                return;

            ClearInviteBeforeTick(thisPlayer);
            _ = SendPhpPlayerJoinedGuildAsync(thisPlayer, invitingPlayer); // async php request, not awaited
        }
        else  //for group invite
        {
            if (thisPlayer.group != null) return;
            if (invitingPlayer.group != null && invitingPlayer.group.groupMembers.Count >= maxGroupSize) return; // @TODO: send "inviting player's group is already at max capacity"

            if (invitingPlayer.group == null) //create a new group
            {
                Group newGroup = new Group(invitingPlayer, thisPlayer);
                groups.Add(newGroup);
            }
            else //add the new player to the existing group
            {
                invitingPlayer.group.groupMembers.Add(thisPlayer);
                thisPlayer.group = invitingPlayer.group;
            }

            ClearInviteBeforeTick(thisPlayer);
            SendGroupUpdateToServers();
        }
    }

    public static void ProcessDeclineInvite(Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null) return;
        
        Player invitingPlayer = thisPlayer.pendingInvite;
        if (invitingPlayer != null)
        {
            byte[] message = MergeByteArrays(ToBytes(Command.DeclineInvite),
            WriteMmoString(thisPlayer.name)); // who refused the invite
            invitingPlayer.SendOrKick(message);
        }
        ClearInviteBeforeTick(thisPlayer);
    }

    public static void ProcessGuildCreate(string guildName, Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null) return;
        guildName = SanitizeStringForXss(guildName, 25); // removes special characters and trims characters after 25 symbols
        _ = SendPhpCreateGuildAsync(thisPlayer, guildName);
    }

    public static void ProcessGuildInvite(string invitedPlayer, Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null) return;
        if (thisPlayer.guildid == 0) return;
        if (!thisPlayer.isGuildLeader) return;

        //find the player that we want to invite
        Player targetPlayer = players.Where(x => x.name == invitedPlayer).SingleOrDefault();
        if (targetPlayer == null || targetPlayer == thisPlayer || targetPlayer.guildid != 0) return;
        if (targetPlayer.pendingInvite != null) return; // he's currently considering an invite, @TODO: send a message back saying it

        CreatePendingInvite(targetPlayer, thisPlayer, true);

        string guildName = guildNames.ContainsKey(thisPlayer.guildid) ? guildNames[thisPlayer.guildid] : "Undefined";
        byte[] message = MergeByteArrays(ToBytes(Command.GuildInvite),
        WriteMmoString(thisPlayer.name),
        WriteMmoString(guildName));

        targetPlayer.SendOrKick(message); //forward the GuildInvite message to the target player
    }

    public static void ProcessGuildDisband(Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null || thisPlayer.guildid == 0 || !thisPlayer.isGuildLeader) return;
        _ = SendPhpDisbandGuildAsync(thisPlayer);
    }

    public static void ProcessGuildLeave(Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);        
        if (thisPlayer == null || thisPlayer.guildid == 0 || thisPlayer.isGuildLeader) return; //for now, the leader can't leave the guild
        Console.WriteLine($"Guild leave: {thisPlayer.name}");
        _ = SendPhpGuildLeaveAsync(thisPlayer);
    }

    public static void ProcessGroupLeave(Socket connection)
    {
        Console.WriteLine("Received group leave!");
        Player thisPlayer = GetPlayer(connection);
        RemoveFromGroup(thisPlayer);
    }

    public static void ProcessGuildKick(string targetPlayerName, Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        if (thisPlayer == null || thisPlayer.guildid == 0 || !thisPlayer.isGuildLeader) return;

        //find the player that we want to kick
        Player targetPlayer = players.Where(x => x.name == targetPlayerName).SingleOrDefault();
        if (targetPlayer == null || thisPlayer.guildid != targetPlayer.guildid) return;

        _ = SendPhpGuildKickAsync(targetPlayer);
    }

    public static void ProcessGroupKick(string targetPlayerName, Socket connection)
    {
        Player thisPlayer = GetPlayer(connection);
        bool isGameServer = gameServers.Contains(connection);

        // if initiating party is player and player is not in group, etc...
        if (!isGameServer && (thisPlayer == null || thisPlayer.group == null || thisPlayer.group.leader != thisPlayer)) return;

        //find the player that we want to kick
        Player targetPlayer = players.Where(x => x.name == targetPlayerName).SingleOrDefault();
        if (targetPlayer == null || targetPlayer.group == null || (!isGameServer && (targetPlayer.group != thisPlayer.group))) return;

        Console.WriteLine($"Kicking from group: {targetPlayerName}");

        if (isGameServer) //kick issued by server (because of disconnect), kick after a delay of X seconds
        {
            CreatePendingKick(targetPlayer);
        }
        else
        {
            RemoveFromGroup(targetPlayer); //kick issued by group leader, kick immediately                                                                 
            //notify the player that they were kicked from the guild
            byte[] message = MergeByteArrays(ToBytes(Command.GroupKick));
            targetPlayer.SendOrKick(message);
        }

    }
}