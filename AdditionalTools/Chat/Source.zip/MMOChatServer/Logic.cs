﻿using System;
using System.Net.Sockets;
using System.Linq;
using Newtonsoft.Json;
using System.Threading.Tasks;

/* 
 * Only contains methods that manage players/groups/etc, and that are expected to be executed on the main thread
 */
public partial class ChatServer
{
    public static Player GetPlayer(Socket connection)
    {
        return connection != null ? players.Where(x => x.socket == connection).SingleOrDefault() : null;
    }

    public static Player GetPlayerByName(string targetPlayerName)
    {
        return players.Where(x => x.name == targetPlayerName).SingleOrDefault();
    }

    public static void PlayerLogin(Socket conn, string charname)
    {
        Player newPlayer = new Player(conn, charname);

        // if it's a character that's in some guild, get his id
        if (characterIds.ContainsKey(newPlayer.name))
        {
            newPlayer.id = characterIds[newPlayer.name];

            // if a guild for this character id is found, assign guild to character
            if (characterGuilds.ContainsKey(newPlayer.id))
                newPlayer.guildid = characterGuilds[newPlayer.id];

            // set him as guild leader if he's in the list of guildleaders
            if (guildLeaders.Contains(newPlayer.id))
                newPlayer.isGuildLeader = true;
        }

        // if it's a reconnecting character, remove him from list of online characters        
        players.RemoveAll(x => x.name == newPlayer.name);
        // add him to list of online characters
        players.Add(newPlayer);

        // update this player in groups if he was in one before reconnecting
        groups.ForEach(group => group.UpdateReconnectedPlayer(newPlayer));

        if (pendingKicks.ContainsKey(newPlayer.name)) //cancel automatic kick
        {
            pendingKicks[newPlayer.name].Stop();
            pendingKicks.Remove(newPlayer.name);
        }
    }

    public static void KickPlayer(Player pl)
    {
        if (pl == null)
            return;

        Console.WriteLine($"Player disconnected: {pl.name}");
        if (pl.group != null)
            RemoveFromGroup(pl);

        players.Remove(pl);
    }

    public static void KickPlayer(Socket connection)
    {
        KickPlayer(GetPlayer(connection));
    }

    public static void KickServer(Socket conn)
    {
        Console.WriteLine("Server disconnected");
        gameServers.Remove(conn);
    }

    public static void KickConnection(Socket connection)
    {
        if (gameServers.Contains(connection))
            KickServer(connection);
        else
            KickPlayer(GetPlayer(connection));
    }

    // clears pending invite if the invite expired
    static void ClearPendingInvite(Player invitedPlayer)
    {
        if (invitedPlayer == null) return;
        Console.WriteLine($"Clearing pending invite for invited player: {invitedPlayer.name}");
        pendingInvites.Remove(invitedPlayer);
        invitedPlayer.pendingInvite = null;
        invitedPlayer.hasPendingGuildInvite = false;
    }

    static void ClearPendingKick(Player playerToKick)
    {
        if (playerToKick == null) return;
        if (pendingKicks.ContainsKey(playerToKick.name)) //cancel automatic kick
        {
            Console.WriteLine($"Clearing pending kick for player: {playerToKick.name}");
            pendingKicks[playerToKick.name].Stop();
            pendingKicks.Remove(playerToKick.name);
        }
    }

    // clears pending invite if it was accepted or declined by the player
    static void ClearInviteBeforeTick(Player targetPlayer)
    {
        if (targetPlayer == null) return;

        Console.WriteLine($"Clearing pending invite due to player accepting/declining: {targetPlayer.name}");

        if (pendingInvites.ContainsKey(targetPlayer))
        {
            pendingInvites[targetPlayer].Stop();
            pendingInvites.Remove(targetPlayer);
        }

        targetPlayer.pendingInvite = null;
        targetPlayer.hasPendingGuildInvite = false;
    }

    public static void CreatePendingInvite(Player invitedPlayer, Player invitingParty, bool bGuildInvite)
    {
        invitedPlayer.pendingInvite = invitingParty;
        invitedPlayer.hasPendingGuildInvite = bGuildInvite;
        double delay = 20000.0; // 20 seconds, 1000 ms is one second
        System.Timers.Timer myTimer = new System.Timers.Timer(delay);
        myTimer.Elapsed += (sender, args) => ConQue.Enqueue(() => ClearPendingInvite(invitedPlayer));
        myTimer.AutoReset = false; // fire only once
        myTimer.Enabled = true;
        pendingInvites.Add(invitedPlayer, myTimer);
    }

    public static void CreatePendingKick(Player playerToKick)
    {
        if (!pendingKicks.ContainsKey(playerToKick.name))
        {
            double delay = 30000.0;
            System.Timers.Timer myTimer = new System.Timers.Timer(delay);
            myTimer.Elapsed += (sender, args) => ConQue.Enqueue(() => ClearPendingKick(playerToKick));
            myTimer.AutoReset = false; // fire only once
            myTimer.Enabled = true;
            pendingKicks.Add(playerToKick.name, myTimer);
        }
    }

    public static async Task SendPhpPlayerJoinedGuildAsync(Player thisPlayer, Player invitingPlayer)
    {
        string PhpResponse = await SendPhpRequestAsync("mmo_clan_add_character",
        "{\"character_name\":\"" + thisPlayer.name + "\"," +
        "\"clan_id\":\"" + invitingPlayer.guildid + "\"}"
        );

        if (PhpResponse.Contains("OK"))
        {
            Console.WriteLine($"Database processed guild invite for player: {thisPlayer.name}");
            ConQue.Enqueue(() => StartGuildsUpdate());
        }
        else
        {
            Console.WriteLine($"Guild invite for {thisPlayer.name} failed. Php response: {PhpResponse}");
        }
    }

    public static async Task SendPhpCreateGuildAsync(Player thisPlayer, string guildName)
    {
        string PhpResponse = await SendPhpRequestAsync("mmo_clan_create",
        "{\"character_name\":\"" + thisPlayer.name + "\"," +
        "\"clan_name\":\"" + guildName + "\"}"
        );

        if (PhpResponse.Contains("OK"))
            ConQue.Enqueue(() => StartGuildsUpdate());
    }

    public static async Task SendPhpDisbandGuildAsync(Player thisPlayer)
    {
        string PhpResponse = await SendPhpRequestAsync("mmo_clan_disband",
        "{\"character_id\":\"" + thisPlayer.id + "\"}"
        );

        if (PhpResponse.Contains("OK"))
        {
            Console.WriteLine($"Guild disbanded by: {thisPlayer.name}");
            ConQue.Enqueue(() => StartGuildsUpdate());
        }
        else
        {
            Console.WriteLine($"Guild disband by {thisPlayer.name} failed. Php response: {PhpResponse}");
        }
    }

    public static async Task SendPhpGuildLeaveAsync(Player thisPlayer)
    {
        string PhpResponse = await SendPhpRequestAsync("mmo_clan_remove_character",
        "{\"character_id\":\"" + thisPlayer.id + "\"}"
        );

        if (PhpResponse.Contains("OK"))
            ConQue.Enqueue(() => StartGuildsUpdate());
    }

    public static async Task SendPhpGuildKickAsync(Player targetPlayer)
    {
        string PhpResponse = await SendPhpRequestAsync("mmo_clan_remove_character",
        "{\"character_id\":\"" + targetPlayer.id + "\"}"
        );

        if (PhpResponse.Contains("OK"))
            ConQue.Enqueue(() => StartGuildsUpdate());
    }

    static void StartGuildsUpdate()
    {
        _ = UpdateGuildsAsync();
    }

    public static async Task UpdateGuildsAsync()
    {
        Console.WriteLine("Requesting guilds from database.");
        string PhpResponse = await SendPhpRequestAsync("mmo_clan_list", "");
        Console.WriteLine("Received guilds.");
        GuildsOutput result = JsonConvert.DeserializeObject<GuildsOutput>(PhpResponse);
        ConQue.Enqueue(() => UpdateGuildsWithInfo(result));
    }

    public static void UpdateGuildsWithInfo(GuildsOutput result)
    {
        characterIds.Clear();
        characterGuilds.Clear();
        guildLeaders.Clear();
        guildNames.Clear();

        players.ForEach(player => player.guildid = 0);

        foreach (var row in result.clans)
        {
            characterIds.Add(row.character_name, row.character_id);
            characterGuilds.Add(row.character_id, row.clan_id);
            if (row.is_leader)
                guildLeaders.Add(row.character_id);

            if (!guildNames.ContainsKey(row.clan_id))
                guildNames.Add(row.clan_id, row.clan_name);

            Player foundPlayer = players.Where(x => x.name == row.character_name).FirstOrDefault();
            if (foundPlayer != null)
            {
                foundPlayer.id = row.character_id;
                foundPlayer.guildid = row.clan_id;
                foundPlayer.isGuildLeader = row.is_leader;
            }
        }

        byte[] message = MergeByteArrays(ToBytes(Command.GuildUpdate)); // inform game servers that they need to update guilds from db by themselves

        foreach (Socket gameServer in gameServers)
        {
            gameServer.SendOrFail(message);
        }
    }

    static void RemoveFromGroup(Player player)
    {
        if (player == null || player.group == null) return;
        Group group = player.group;

        Console.WriteLine($"Kicking player from group: {player.name}");

        group.groupMembers.Remove(player);
        player.group = null;

        if (group.groupMembers.Count > 1)
        {
            if (group.leader == player) // if party leader left, assign party leadership to someone else
            {                
                group.leader = group.groupMembers[0];
            }
        }
        else //if there is less than 2 players now, disband the group
        {
            group.groupMembers[0].group = null;
            groups.Remove(group);
        }
        SendGroupUpdateToServers();
    }

    static void SendGroupUpdateToServers()
    {
        string playerNames = "";
        foreach (Group group in groups) //each group is divided by ":", each group member is divided by ','
        {
            playerNames += group.GetPlayerNames();
            playerNames += ":";
        }

        byte[] message = MergeByteArrays(ToBytes(Command.GroupUpdate),
        WriteMmoString(playerNames));

        foreach (Socket gameServer in gameServers)
        {
            gameServer.SendOrFail(message);
        }
    }

    private static string SanitizeStringForXss(string inputString, int maxLength)
    {
        string result;
        result = inputString.Length <= maxLength ? inputString : inputString.Substring(0, maxLength); // trim to max length chars
        result = result.Replace("'", string.Empty);
        result = result.Replace("\"", string.Empty);
        result = result.Replace("`", string.Empty);
        return result;
    }

    // when a new game server connects, send it all the groups we currently have
    static void InitializeGroupsOnServer()
    {

    }
}